
  # Business Website for Renovation

  This is a code bundle for Business Website for Renovation. The original project is available at https://www.figma.com/design/WoBD1tnxNZb8iaRC8V5wul/Business-Website-for-Renovation.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  