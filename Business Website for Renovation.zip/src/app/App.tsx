import { useState, useEffect } from "react";
import { Menu, X, Phone, Mail, MapPin, ChevronRight, Building2, Factory, Home, Award, Users, CheckCircle, Star, ArrowRight, Shield, Clock } from "lucide-react";
import logoSvg from "../imports/Logo.svg";

const NAV_LINKS = [
  { label: "หน้าแรก", href: "#home" },
  { label: "บริการ", href: "#services" },
  { label: "ผลงาน", href: "#projects" },
  { label: "เกี่ยวกับเรา", href: "#about" },
  { label: "ติดต่อ", href: "#contact" },
];

const SERVICES = [
  {
    icon: Building2,
    title: "อาคารพาณิชย์",
    subtitle: "Commercial Buildings",
    desc: "รับเหมาก่อสร้างและปรับปรุงอาคารพาณิชย์ทุกประเภท ออฟฟิศ คอนโดมิเนียม และอาคารสำนักงาน ด้วยมาตรฐานสูงสุด",
    img: "https://images.unsplash.com/photo-1508450859948-4e04fabaa4ea?w=600&h=400&fit=crop&auto=format",
  },
  {
    icon: Factory,
    title: "โรงงานอุตสาหกรรม",
    subtitle: "Industrial Factories",
    desc: "ออกแบบและก่อสร้างโรงงานอุตสาหกรรม คลังสินค้า และนิคมอุตสาหกรรม ตามมาตรฐานความปลอดภัยสากล",
    img: "https://images.unsplash.com/photo-1511454493857-0a29f2c023c7?w=600&h=400&fit=crop&auto=format",
  },
  {
    icon: Home,
    title: "บ้านและที่พักอาศัย",
    subtitle: "Residential Homes",
    desc: "รับสร้างบ้านใหม่และต่อเติมปรับปรุงบ้าน ทาวน์เฮาส์ บ้านเดี่ยว ด้วยฝีมือประณีตและวัสดุคุณภาพ",
    img: "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&h=400&fit=crop&auto=format",
  },
];

const PROJECTS = [
  {
    title: "อาคารสำนักงาน ABC Corp",
    category: "อาคารพาณิชย์",
    location: "กรุงเทพมหานคร",
    year: "2567",
    img: "https://images.unsplash.com/photo-1601074231509-dce351c05199?w=600&h=400&fit=crop&auto=format",
  },
  {
    title: "โรงงานผลิต XYZ Industry",
    category: "โรงงาน",
    location: "สมุทรปราการ",
    year: "2566",
    img: "https://images.unsplash.com/photo-1615797534094-7fde0a4861f3?w=600&h=400&fit=crop&auto=format",
  },
  {
    title: "บ้านเดี่ยว 2 ชั้น โครงการ A",
    category: "บ้านพักอาศัย",
    location: "นนทบุรี",
    year: "2567",
    img: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&h=400&fit=crop&auto=format",
  },
  {
    title: "ต่อเติมคลังสินค้า DEF Logistics",
    category: "โรงงาน",
    location: "ปทุมธานี",
    year: "2566",
    img: "https://images.unsplash.com/photo-1543304376-1ae7c2be5e59?w=600&h=400&fit=crop&auto=format",
  },
  {
    title: "ปรับปรุงอาคาร Retail Park",
    category: "อาคารพาณิชย์",
    location: "เชียงใหม่",
    year: "2565",
    img: "https://images.unsplash.com/photo-1551711974-faf378be34b2?w=600&h=400&fit=crop&auto=format",
  },
  {
    title: "บ้านสองชั้น Luxury Series",
    category: "บ้านพักอาศัย",
    location: "ภูเก็ต",
    year: "2567",
    img: "https://images.unsplash.com/photo-1721815693498-cc28507c0ba2?w=600&h=400&fit=crop&auto=format",
  },
];

const STATS = [
  { value: "15+", label: "ปีประสบการณ์" },
  { value: "350+", label: "โครงการสำเร็จ" },
  { value: "98%", label: "ลูกค้าพึงพอใจ" },
  { value: "50+", label: "ทีมวิศวกรและช่าง" },
];

const TESTIMONIALS = [
  {
    name: "คุณสมชาย วงศ์ดี",
    role: "เจ้าของโรงงาน บริษัท ไทยโปรดักส์ จำกัด",
    text: "ทีมงานมืออาชีพมาก ก่อสร้างโรงงานเสร็จตามกำหนด งานเรียบร้อยได้มาตรฐาน ราคายุติธรรม จะใช้บริการอีกแน่นอน",
    rating: 5,
  },
  {
    name: "คุณนิดา รักษาดี",
    role: "เจ้าของบ้าน โครงการ The Residence",
    text: "สร้างบ้านฝันได้เป็นจริง ทีมงานใส่ใจในรายละเอียดทุกจุด วัสดุคุณภาพดี ติดต่อสื่อสารง่าย อัปเดตความคืบหน้าตลอด",
    rating: 5,
  },
  {
    name: "คุณวิชัย ประสิทธิ์ชัย",
    role: "ผู้จัดการอาคาร ABC Office Tower",
    text: "ปรับปรุงอาคารสำนักงานได้สวยงาม ทันสมัย ลูกค้าของเราชื่นชมมาก ทำงานสะอาด ไม่รบกวนการใช้งาน",
    rating: 5,
  },
];

const WHY_US = [
  { icon: Shield, title: "รับประกันงาน 2 ปี", desc: "ทุกโครงการรับประกันคุณภาพงานก่อสร้างนาน 2 ปี" },
  { icon: HardHat, title: "ทีมวิศวกรมืออาชีพ", desc: "วิศวกรและสถาปนิกผู้เชี่ยวชาญมากกว่า 20 คน" },
  { icon: Clock, title: "ส่งงานตรงเวลา", desc: "ติดตามความคืบหน้าแบบ Real-time ส่งงานตามสัญญา" },
  { icon: CheckCircle, title: "วัสดุได้มาตรฐาน", desc: "คัดสรรวัสดุคุณภาพสูงจากแบรนด์ที่เชื่อถือได้" },
];

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [activeFilter, setActiveFilter] = useState("ทั้งหมด");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const categories = ["ทั้งหมด", "อาคารพาณิชย์", "โรงงาน", "บ้านพักอาศัย"];
  const filteredProjects = activeFilter === "ทั้งหมด"
    ? PROJECTS
    : PROJECTS.filter(p => p.category === activeFilter);

  const scrollTo = (href: string) => {
    setMenuOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div
      className="min-h-screen bg-background text-foreground"
      style={{ fontFamily: "'Kanit', sans-serif" }}
    >
      {/* MARKER-MAKE-KIT-INVOKED */}

      {/* ── NAVBAR ── */}
      <nav
        className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
        style={{
          background: scrolled ? "rgba(15,17,23,0.97)" : "transparent",
          borderBottom: scrolled ? "1px solid rgba(212,135,26,0.2)" : "none",
          backdropFilter: scrolled ? "blur(12px)" : "none",
        }}
      >
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <a href="#home" onClick={(e) => { e.preventDefault(); scrollTo("#home"); }} className="flex items-center gap-3">
            <img src={logoSvg} alt="Design I.KETEC Logo" style={{ height: "40px", width: "auto", filter: "brightness(0) invert(1)" }} />
            <div>
              <div style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1rem", fontWeight: 700, color: "#f0ede8", lineHeight: 1.15 }}>
                ดีไซน์ ไอ.คีเท็ค
              </div>
              <div style={{ fontSize: "0.6rem", letterSpacing: "0.1em", color: "#d4871a", textTransform: "uppercase" }}>
                DESIGN I.KETEC CO., LTD.
              </div>
            </div>
          </a>

          {/* Desktop nav */}
          <div className="hidden md:flex items-center gap-8">
            {NAV_LINKS.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => { e.preventDefault(); scrollTo(link.href); }}
                className="transition-colors duration-200"
                style={{ fontSize: "0.9rem", letterSpacing: "0.03em", color: "#9a9488" }}
                onMouseEnter={e => (e.currentTarget.style.color = "#d4871a")}
                onMouseLeave={e => (e.currentTarget.style.color = "#9a9488")}
              >
                {link.label}
              </a>
            ))}
            <button
              onClick={() => scrollTo("#contact")}
              className="px-5 py-2 transition-all duration-200"
              style={{ background: "#d4871a", color: "#0f1117", fontWeight: 600, fontSize: "0.85rem", letterSpacing: "0.05em" }}
              onMouseEnter={e => (e.currentTarget.style.background = "#e89c2f")}
              onMouseLeave={e => (e.currentTarget.style.background = "#d4871a")}
            >
              ขอใบเสนอราคา
            </button>
          </div>

          {/* Mobile hamburger */}
          <button className="md:hidden" style={{ color: "#f0ede8" }} onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile menu */}
        {menuOpen && (
          <div style={{ background: "#0f1117", borderTop: "1px solid rgba(212,135,26,0.2)" }} className="md:hidden px-6 py-6 flex flex-col gap-4">
            {NAV_LINKS.map(link => (
              <a
                key={link.href}
                href={link.href}
                onClick={(e) => { e.preventDefault(); scrollTo(link.href); }}
                style={{ color: "#9a9488", fontSize: "1rem", letterSpacing: "0.03em" }}
              >
                {link.label}
              </a>
            ))}
            <button
              onClick={() => scrollTo("#contact")}
              className="mt-2 py-3 w-full"
              style={{ background: "#d4871a", color: "#0f1117", fontWeight: 600 }}
            >
              ขอใบเสนอราคา
            </button>
          </div>
        )}
      </nav>

      {/* ── HERO ── */}
      <section id="home" className="relative min-h-screen flex items-center overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `url(https://images.unsplash.com/photo-1601074231509-dce351c05199?w=1600&h=900&fit=crop&auto=format)`,
            backgroundSize: "cover",
            backgroundPosition: "center",
          }}
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(105deg, rgba(15,17,23,0.92) 55%, rgba(15,17,23,0.5) 100%)" }} />

        {/* Amber side accent bar */}
        <div className="absolute top-0 left-0 w-1 h-full" style={{ background: "#d4871a" }} />

        <div className="relative max-w-7xl mx-auto px-6 py-32">
          <div className="max-w-2xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-px" style={{ background: "#d4871a" }} />
              <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>
                รับเหมาก่อสร้างครบวงจร
              </span>
            </div>
            <h1
              style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(3rem, 8vw, 5.5rem)", fontWeight: 800, lineHeight: 1.0, letterSpacing: "-0.01em", color: "#f0ede8" }}
            >
              สร้างทุกความ<br />
              <span style={{ color: "#d4871a" }}>ฝันให้เป็นจริง</span>
            </h1>
            <p style={{ marginTop: "1.5rem", fontSize: "1.05rem", color: "#9a9488", lineHeight: 1.75, maxWidth: "520px" }}>
              รับเหมาก่อสร้างและปรับปรุง อาคาร โรงงาน และบ้านพักอาศัย ด้วยประสบการณ์กว่า 15 ปี ทีมวิศวกรมืออาชีพ และมาตรฐานสูงสุด
            </p>
            <div className="flex flex-wrap gap-4 mt-10">
              <button
                onClick={() => scrollTo("#contact")}
                className="flex items-center gap-2 px-8 py-4 transition-all duration-200"
                style={{ background: "#d4871a", color: "#0f1117", fontWeight: 700, fontSize: "0.95rem", letterSpacing: "0.05em" }}
                onMouseEnter={e => (e.currentTarget.style.background = "#e89c2f")}
                onMouseLeave={e => (e.currentTarget.style.background = "#d4871a")}
              >
                ปรึกษาฟรี <ArrowRight size={18} />
              </button>
              <button
                onClick={() => scrollTo("#projects")}
                className="flex items-center gap-2 px-8 py-4 transition-all duration-200"
                style={{ border: "1px solid rgba(212,135,26,0.5)", color: "#d4871a", fontWeight: 600, fontSize: "0.95rem" }}
                onMouseEnter={e => { e.currentTarget.style.background = "rgba(212,135,26,0.1)"; }}
                onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
              >
                ดูผลงาน
              </button>
            </div>
          </div>

          {/* Stats strip */}
          <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-px" style={{ background: "rgba(255,255,255,0.06)" }}>
            {STATS.map((s) => (
              <div key={s.label} className="px-6 py-5" style={{ background: "rgba(15,17,23,0.7)" }}>
                <div style={{ fontFamily: "'Kanit', sans-serif", fontSize: "2.2rem", fontWeight: 800, color: "#d4871a", lineHeight: 1 }}>{s.value}</div>
                <div style={{ fontSize: "0.8rem", color: "#9a9488", marginTop: "4px", letterSpacing: "0.05em" }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SERVICES ── */}
      <section id="services" className="py-24" style={{ background: "#0f1117" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-14">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: "#d4871a" }} />
              <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>บริการของเรา</span>
            </div>
            <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(2rem, 5vw, 3.2rem)", fontWeight: 800, color: "#f0ede8", lineHeight: 1.1 }}>
              ครอบคลุมทุกประเภทการก่อสร้าง
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-px" style={{ background: "rgba(255,255,255,0.06)" }}>
            {SERVICES.map((svc) => (
              <div
                key={svc.title}
                className="group relative overflow-hidden"
                style={{ background: "#1a1c24" }}
              >
                <div className="overflow-hidden" style={{ height: "220px", background: "#252830" }}>
                  <img
                    src={svc.img}
                    alt={svc.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300" style={{ background: "rgba(212,135,26,0.15)" }} />
                </div>
                <div className="p-8">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 flex items-center justify-center" style={{ background: "rgba(212,135,26,0.12)", border: "1px solid rgba(212,135,26,0.3)" }}>
                      <svc.icon size={18} color="#d4871a" />
                    </div>
                    <div>
                      <div style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1.25rem", fontWeight: 700, color: "#f0ede8", lineHeight: 1.1 }}>{svc.title}</div>
                      <div style={{ fontSize: "0.7rem", color: "#d4871a", letterSpacing: "0.12em", textTransform: "uppercase" }}>{svc.subtitle}</div>
                    </div>
                  </div>
                  <p style={{ fontSize: "0.9rem", color: "#9a9488", lineHeight: 1.7 }}>{svc.desc}</p>
                  <div className="mt-6 flex items-center gap-2 cursor-pointer group/link" onClick={() => scrollTo("#contact")}>
                    <span style={{ fontSize: "0.8rem", color: "#d4871a", letterSpacing: "0.08em", fontWeight: 600 }}>ดูรายละเอียด</span>
                    <ChevronRight size={14} color="#d4871a" className="group-hover/link:translate-x-1 transition-transform duration-200" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY US ── */}
      <section className="py-24" style={{ background: "#13151e" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-px" style={{ background: "#d4871a" }} />
                <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>ทำไมต้องเรา</span>
              </div>
              <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)", fontWeight: 800, color: "#f0ede8", lineHeight: 1.1, marginBottom: "1.25rem" }}>
                มาตรฐานสูงสุด<br />ทุกโครงการ
              </h2>
              <p style={{ fontSize: "0.95rem", color: "#9a9488", lineHeight: 1.8 }}>
                เราเชื่อมั่นในคุณภาพงานและความพึงพอใจของลูกค้า ด้วยระบบควบคุมคุณภาพที่เข้มงวดและทีมงานมืออาชีพ ทุกโครงการจึงได้รับการดูแลอย่างใกล้ชิดตั้งแต่เริ่มต้นจนส่งมอบงาน
              </p>

              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-4">
                {WHY_US.map((item) => (
                  <div key={item.title} className="flex gap-4 p-5" style={{ background: "#1a1c24", border: "1px solid rgba(255,255,255,0.06)" }}>
                    <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center" style={{ background: "rgba(212,135,26,0.1)" }}>
                      <item.icon size={18} color="#d4871a" />
                    </div>
                    <div>
                      <div style={{ fontSize: "0.9rem", fontWeight: 600, color: "#f0ede8", marginBottom: "4px" }}>{item.title}</div>
                      <div style={{ fontSize: "0.8rem", color: "#9a9488", lineHeight: 1.6 }}>{item.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] overflow-hidden" style={{ background: "#252830" }}>
                <img
                  src="https://images.unsplash.com/photo-1517581177682-a085bb7ffb15?w=700&h=900&fit=crop&auto=format"
                  alt="ทีมงานก่อสร้างมืออาชีพ"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0" style={{ background: "linear-gradient(to top, rgba(15,17,23,0.6) 0%, transparent 60%)" }} />
              </div>
              <div className="absolute -bottom-6 -left-6 p-6" style={{ background: "#d4871a", width: "180px" }}>
                <div style={{ fontFamily: "'Kanit', sans-serif", fontSize: "2.5rem", fontWeight: 800, color: "#0f1117", lineHeight: 1 }}>15+</div>
                <div style={{ fontSize: "0.8rem", color: "#0f1117", fontWeight: 600, marginTop: "4px" }}>ปีประสบการณ์</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ── PROJECTS ── */}
      <section id="projects" className="py-24" style={{ background: "#0f1117" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-px" style={{ background: "#d4871a" }} />
                <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>ผลงานของเรา</span>
              </div>
              <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(2rem, 5vw, 3.2rem)", fontWeight: 800, color: "#f0ede8", lineHeight: 1.1 }}>
                โครงการที่ผ่านมา
              </h2>
            </div>
            <div className="flex flex-wrap gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveFilter(cat)}
                  className="px-4 py-2 text-sm transition-all duration-200"
                  style={{
                    background: activeFilter === cat ? "#d4871a" : "transparent",
                    color: activeFilter === cat ? "#0f1117" : "#9a9488",
                    border: "1px solid",
                    borderColor: activeFilter === cat ? "#d4871a" : "rgba(255,255,255,0.1)",
                    fontWeight: activeFilter === cat ? 600 : 400,
                    fontSize: "0.8rem",
                    letterSpacing: "0.03em",
                  }}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-px" style={{ background: "rgba(255,255,255,0.06)" }}>
            {filteredProjects.map((project) => (
              <div key={project.title} className="group relative overflow-hidden" style={{ background: "#1a1c24" }}>
                <div className="overflow-hidden" style={{ height: "240px", background: "#252830" }}>
                  <img
                    src={project.img}
                    alt={project.title}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 transition-opacity duration-300" style={{ background: "linear-gradient(to top, rgba(15,17,23,0.85) 0%, transparent 60%)" }} />
                  <div
                    className="absolute top-3 left-3 px-3 py-1"
                    style={{ background: "#d4871a", fontSize: "0.65rem", color: "#0f1117", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase" }}
                  >
                    {project.category}
                  </div>
                </div>
                <div className="p-6">
                  <h3 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1.15rem", fontWeight: 700, color: "#f0ede8", marginBottom: "8px" }}>
                    {project.title}
                  </h3>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1">
                      <MapPin size={12} color="#9a9488" />
                      <span style={{ fontSize: "0.78rem", color: "#9a9488" }}>{project.location}</span>
                    </div>
                    <div style={{ fontSize: "0.78rem", color: "#9a9488" }}>ปี {project.year}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── TESTIMONIALS ── */}
      <section id="about" className="py-24" style={{ background: "#13151e" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="mb-14 text-center">
            <div className="flex items-center justify-center gap-3 mb-4">
              <div className="w-8 h-px" style={{ background: "#d4871a" }} />
              <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>เสียงจากลูกค้า</span>
              <div className="w-8 h-px" style={{ background: "#d4871a" }} />
            </div>
            <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)", fontWeight: 800, color: "#f0ede8" }}>
              ลูกค้าพูดถึงเรา
            </h2>
          </div>

          <div className="grid md:grid-cols-3 gap-px" style={{ background: "rgba(255,255,255,0.06)" }}>
            {TESTIMONIALS.map((t) => (
              <div key={t.name} className="p-8" style={{ background: "#1a1c24" }}>
                <div className="flex gap-1 mb-5">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star key={i} size={14} fill="#d4871a" color="#d4871a" />
                  ))}
                </div>
                <p style={{ fontSize: "0.92rem", color: "#c8c4bc", lineHeight: 1.75, marginBottom: "1.5rem" }}>
                  "{t.text}"
                </p>
                <div className="flex items-center gap-3 pt-5" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
                  <div className="w-10 h-10 flex items-center justify-center" style={{ background: "#d4871a" }}>
                    <Users size={18} color="#0f1117" />
                  </div>
                  <div>
                    <div style={{ fontSize: "0.9rem", fontWeight: 600, color: "#f0ede8" }}>{t.name}</div>
                    <div style={{ fontSize: "0.75rem", color: "#9a9488" }}>{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ── */}
      <section className="py-20" style={{ background: "#d4871a" }}>
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(1.8rem, 4vw, 2.8rem)", fontWeight: 800, color: "#0f1117", lineHeight: 1.1 }}>
              พร้อมเริ่มโครงการของคุณ?
            </h2>
            <p style={{ fontSize: "1rem", color: "rgba(15,17,23,0.7)", marginTop: "8px" }}>
              ปรึกษาฟรี — ทีมงานพร้อมให้คำแนะนำทุกวัน
            </p>
          </div>
          <div className="flex flex-wrap gap-4">
            <a
              href="tel:+6621234567"
              className="flex items-center gap-2 px-7 py-4"
              style={{ background: "#0f1117", color: "#f0ede8", fontWeight: 700, fontSize: "0.9rem" }}
            >
              <Phone size={16} /> โทรหาเรา
            </a>
            <button
              onClick={() => scrollTo("#contact")}
              className="flex items-center gap-2 px-7 py-4"
              style={{ border: "2px solid #0f1117", color: "#0f1117", fontWeight: 700, fontSize: "0.9rem" }}
              onMouseEnter={e => { e.currentTarget.style.background = "rgba(15,17,23,0.1)"; }}
              onMouseLeave={e => { e.currentTarget.style.background = "transparent"; }}
            >
              ส่งข้อความ <ArrowRight size={16} />
            </button>
          </div>
        </div>
      </section>

      {/* ── CONTACT ── */}
      <section id="contact" className="py-24" style={{ background: "#0f1117" }}>
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid lg:grid-cols-2 gap-16">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-8 h-px" style={{ background: "#d4871a" }} />
                <span style={{ color: "#d4871a", fontSize: "0.75rem", letterSpacing: "0.2em", textTransform: "uppercase", fontWeight: 600 }}>ติดต่อเรา</span>
              </div>
              <h2 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "clamp(2rem, 5vw, 3rem)", fontWeight: 800, color: "#f0ede8", lineHeight: 1.1, marginBottom: "1.5rem" }}>
                เริ่มต้นโครงการ<br />ของคุณวันนี้
              </h2>
              <p style={{ fontSize: "0.95rem", color: "#9a9488", lineHeight: 1.8, marginBottom: "2.5rem" }}>
                กรอกรายละเอียดโครงการของคุณ ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง พร้อมให้คำปรึกษาและจัดทำใบเสนอราคาฟรี
              </p>

              <div className="flex flex-col gap-5">
                {[
                  { icon: Phone, label: "โทรศัพท์", value: "02-123-4567 / 081-234-5678" },
                  { icon: Mail, label: "อีเมล", value: "info@siamconstruction.co.th" },
                  { icon: MapPin, label: "ที่อยู่", value: "229 ซอยอินทราภรณ์ แขวงพลับพลา เขตวังทองหลาง กรุงเทพมหานคร 10310" },
                ].map((item) => (
                  <div key={item.label} className="flex items-start gap-4">
                    <div className="w-10 h-10 flex-shrink-0 flex items-center justify-center" style={{ background: "rgba(212,135,26,0.1)", border: "1px solid rgba(212,135,26,0.2)" }}>
                      <item.icon size={16} color="#d4871a" />
                    </div>
                    <div>
                      <div style={{ fontSize: "0.75rem", color: "#d4871a", fontWeight: 600, letterSpacing: "0.08em", marginBottom: "2px" }}>{item.label}</div>
                      <div style={{ fontSize: "0.9rem", color: "#c8c4bc" }}>{item.value}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Contact Form */}
            <div className="p-8" style={{ background: "#1a1c24", border: "1px solid rgba(255,255,255,0.06)" }}>
              <h3 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1.5rem", fontWeight: 700, color: "#f0ede8", marginBottom: "1.5rem" }}>
                ส่งข้อความถึงเรา
              </h3>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* ── FOOTER ── */}
      <footer style={{ background: "#0a0c12", borderTop: "1px solid rgba(212,135,26,0.15)" }}>
        <div className="max-w-7xl mx-auto px-6 py-12">
          <div className="grid md:grid-cols-4 gap-10 mb-12">
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <img src={logoSvg} alt="Design I.KETEC Logo" style={{ height: "44px", width: "auto", filter: "brightness(0) invert(1)" }} />
                <div>
                  <div style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1rem", fontWeight: 700, color: "#f0ede8", lineHeight: 1.2 }}>บริษัท ดีไซน์ ไอ.คีเท็ค จำกัด</div>
                  <div style={{ fontSize: "0.6rem", color: "#d4871a", letterSpacing: "0.1em", textTransform: "uppercase" }}>DESIGN I.KETEC COMPANY LIMITED</div>
                </div>
              </div>
              <p style={{ fontSize: "0.85rem", color: "#9a9488", lineHeight: 1.8, maxWidth: "360px" }}>
                รับเหมาก่อสร้างและปรับปรุง อาคาร โรงงาน และบ้านพักอาศัย ด้วยประสบการณ์กว่า 15 ปี และทีมวิศวกรมืออาชีพ
              </p>
              <div className="flex items-center gap-3 mt-5">
                {[Award, Shield, CheckCircle].map((Icon, i) => (
                  <div key={i} className="w-8 h-8 flex items-center justify-center" style={{ border: "1px solid rgba(212,135,26,0.2)" }}>
                    <Icon size={14} color="#d4871a" />
                  </div>
                ))}
                <span style={{ fontSize: "0.75rem", color: "#9a9488" }}>มาตรฐาน ISO 9001</span>
              </div>
            </div>

            <div>
              <div style={{ fontSize: "0.75rem", color: "#d4871a", letterSpacing: "0.15em", textTransform: "uppercase", fontWeight: 600, marginBottom: "1rem" }}>บริการ</div>
              {["อาคารพาณิชย์", "โรงงานอุตสาหกรรม", "บ้านพักอาศัย", "ต่อเติมอาคาร", "รีโนเวท"].map(item => (
                <div key={item} style={{ fontSize: "0.85rem", color: "#9a9488", marginBottom: "8px", cursor: "pointer" }}
                  onMouseEnter={e => (e.currentTarget.style.color = "#d4871a")}
                  onMouseLeave={e => (e.currentTarget.style.color = "#9a9488")}
                >
                  {item}
                </div>
              ))}
            </div>

            <div>
              <div style={{ fontSize: "0.75rem", color: "#d4871a", letterSpacing: "0.15em", textTransform: "uppercase", fontWeight: 600, marginBottom: "1rem" }}>เวลาทำการ</div>
              <div style={{ fontSize: "0.85rem", color: "#9a9488", lineHeight: 1.9 }}>
                <div>จันทร์ – ศุกร์</div>
                <div style={{ color: "#f0ede8" }}>08:00 – 17:30 น.</div>
                <div className="mt-2">เสาร์</div>
                <div style={{ color: "#f0ede8" }}>08:00 – 12:00 น.</div>
                <div className="mt-2">อาทิตย์</div>
                <div>ปิดทำการ</div>
              </div>
            </div>
          </div>

          <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4" style={{ borderTop: "1px solid rgba(255,255,255,0.06)" }}>
            <div style={{ fontSize: "0.78rem", color: "#9a9488" }}>
              © 2567 บริษัท ดีไซน์ ไอ.คีเท็ค จำกัด. สงวนลิขสิทธิ์ทุกประการ
            </div>
            <div className="flex gap-6">
              {["นโยบายความเป็นส่วนตัว", "เงื่อนไขการใช้งาน"].map(item => (
                <span key={item} style={{ fontSize: "0.78rem", color: "#9a9488", cursor: "pointer" }}
                  onMouseEnter={e => (e.currentTarget.style.color = "#d4871a")}
                  onMouseLeave={e => (e.currentTarget.style.color = "#9a9488")}
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

function ContactForm() {
  const [form, setForm] = useState({ name: "", phone: "", email: "", type: "", message: "" });
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const inputStyle: React.CSSProperties = {
    width: "100%",
    padding: "10px 14px",
    background: "#252830",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "#f0ede8",
    fontSize: "0.9rem",
    outline: "none",
  };

  if (submitted) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-4">
        <div className="w-14 h-14 flex items-center justify-center" style={{ background: "#d4871a" }}>
          <CheckCircle size={28} color="#0f1117" />
        </div>
        <h4 style={{ fontFamily: "'Kanit', sans-serif", fontSize: "1.5rem", fontWeight: 700, color: "#f0ede8" }}>
          ส่งข้อความแล้ว!
        </h4>
        <p style={{ fontSize: "0.9rem", color: "#9a9488", textAlign: "center" }}>
          ทีมงานจะติดต่อกลับภายใน 24 ชั่วโมง ขอบคุณที่ไว้วางใจ ดีไซน์ ไอ.คีเท็ค
        </p>
        <button
          onClick={() => setSubmitted(false)}
          style={{ marginTop: "8px", fontSize: "0.85rem", color: "#d4871a", textDecoration: "underline" }}
        >
          ส่งข้อความใหม่
        </button>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label style={{ fontSize: "0.75rem", color: "#9a9488", display: "block", marginBottom: "6px", letterSpacing: "0.05em" }}>ชื่อ-นามสกุล *</label>
          <input
            required
            style={inputStyle}
            value={form.name}
            onChange={e => setForm({ ...form, name: e.target.value })}
            placeholder="กรอกชื่อ-นามสกุล"
          />
        </div>
        <div>
          <label style={{ fontSize: "0.75rem", color: "#9a9488", display: "block", marginBottom: "6px", letterSpacing: "0.05em" }}>เบอร์โทร *</label>
          <input
            required
            style={inputStyle}
            value={form.phone}
            onChange={e => setForm({ ...form, phone: e.target.value })}
            placeholder="0X-XXXX-XXXX"
          />
        </div>
      </div>
      <div>
        <label style={{ fontSize: "0.75rem", color: "#9a9488", display: "block", marginBottom: "6px", letterSpacing: "0.05em" }}>อีเมล</label>
        <input
          type="email"
          style={inputStyle}
          value={form.email}
          onChange={e => setForm({ ...form, email: e.target.value })}
          placeholder="example@email.com"
        />
      </div>
      <div>
        <label style={{ fontSize: "0.75rem", color: "#9a9488", display: "block", marginBottom: "6px", letterSpacing: "0.05em" }}>ประเภทงาน *</label>
        <select
          required
          style={{ ...inputStyle, cursor: "pointer" }}
          value={form.type}
          onChange={e => setForm({ ...form, type: e.target.value })}
        >
          <option value="" disabled>เลือกประเภทงาน</option>
          <option value="building">อาคารพาณิชย์</option>
          <option value="factory">โรงงานอุตสาหกรรม</option>
          <option value="home">บ้านพักอาศัย</option>
          <option value="renovate">ต่อเติม/รีโนเวท</option>
          <option value="other">อื่นๆ</option>
        </select>
      </div>
      <div>
        <label style={{ fontSize: "0.75rem", color: "#9a9488", display: "block", marginBottom: "6px", letterSpacing: "0.05em" }}>รายละเอียดโครงการ</label>
        <textarea
          rows={4}
          style={{ ...inputStyle, resize: "vertical" }}
          value={form.message}
          onChange={e => setForm({ ...form, message: e.target.value })}
          placeholder="อธิบายโครงการ ขนาด งบประมาณ ระยะเวลา ฯลฯ"
        />
      </div>
      <button
        type="submit"
        className="w-full py-4 flex items-center justify-center gap-2 mt-2 transition-all duration-200"
        style={{ background: "#d4871a", color: "#0f1117", fontWeight: 700, fontSize: "0.95rem", letterSpacing: "0.05em" }}
        onMouseEnter={e => (e.currentTarget.style.background = "#e89c2f")}
        onMouseLeave={e => (e.currentTarget.style.background = "#d4871a")}
      >
        ส่งข้อความ <ArrowRight size={18} />
      </button>
    </form>
  );
}
